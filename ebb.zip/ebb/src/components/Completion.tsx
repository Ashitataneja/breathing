import { useState } from 'react';
import { Feeling, SessionRecord, updateSession } from '../storage/store';
import { formatDuration } from '../lib/format';

interface Props {
  record: SessionRecord;
  reachedPlanned: boolean;
  totalSessions: number;
  onAgain: () => void;
  onDone: () => void;
  onSky: () => void;
}

const FEELINGS: { id: Feeling; label: string; reply: string }[] = [
  { id: 'calmer', label: 'Calmer', reply: 'Let that stay with you a while.' },
  { id: 'clearer', label: 'Clearer', reply: 'A little more room to think.' },
  { id: 'same', label: 'About the same', reply: 'That’s fine. The practice still happened.' },
  { id: 'restless', label: 'Restless', reply: 'That’s alright. Noticing it is part of the practice.' },
  { id: 'tired', label: 'Tired', reply: 'Maybe rest is what your body is asking for.' },
];

const ordinal = (n: number) => {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
};

export function Completion({ record, reachedPlanned, totalSessions, onAgain, onDone, onSky }: Props) {
  const [feeling, setFeeling] = useState<Feeling | undefined>(record.feeling);
  const duration = formatDuration(record.activeSeconds);
  const chosen = FEELINGS.find((f) => f.id === feeling);

  const choose = (f: Feeling) => {
    const next = feeling === f ? undefined : f;
    setFeeling(next);
    updateSession(record.id, { feeling: next });
  };

  return (
    <main className="screen completion">
      <section className="completion-body">
        <p className="eyebrow">{reachedPlanned ? 'Session complete' : 'Session ended'}</p>
        <h1 className="display">
          {reachedPlanned ? `You breathed for ${duration}.` : `You took ${duration} for yourself.`}
        </h1>
        <p className="lede">
          {record.breaths > 0 ? `About ${record.breaths} slow breaths. ` : ''}
          {totalSessions === 1
            ? 'Your first star is in the sky.'
            : `Your ${ordinal(totalSessions)} session — a new star joins your sky.`}
        </p>

        <fieldset className="reflect">
          <legend>How do you feel now?</legend>
          <div className="chips">
            {FEELINGS.map((f) => (
              <button key={f.id} className={`chip ${feeling === f.id ? 'is-on' : ''}`} aria-pressed={feeling === f.id} onClick={() => choose(f.id)}>
                {f.label}
              </button>
            ))}
          </div>
          <p className="reflect-reply" aria-live="polite">{chosen?.reply ?? ' '}</p>
        </fieldset>

        <div className="completion-actions">
          <button className="begin" onClick={onAgain}>Breathe again</button>
          <div className="completion-links">
            <button className="quiet-link" onClick={onSky}>See your sky</button>
            <button className="quiet-link" onClick={onDone}>Done</button>
          </div>
        </div>
      </section>
    </main>
  );
}
