import { MutableRefObject, useEffect, useRef, useState } from 'react';
import { FrameInput, Garden, SkyStar } from '../render/Garden';

export type Driver = (now: number) => FrameInput;

interface Props {
  driver: MutableRefObject<Driver>;
  stars: SkyStar[];
}

/**
 * Owns the single, persistent canvas behind every screen. Each animation
 * frame asks the current driver (landing preview, live session, …) what the
 * breath looks like right now, then hands that to the renderer.
 *
 * If Canvas 2D is unavailable, a simple DOM glow follows the same driver so
 * the breathing guidance still works.
 */
export function BreathCanvas({ driver, stars }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fallbackRef = useRef<HTMLDivElement>(null);
  const gardenRef = useRef<Garden | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    gardenRef.current?.setSky(stars);
  }, [stars]);

  useEffect(() => {
    const canvas = canvasRef.current;
    let garden: Garden | null = null;
    if (canvas && !failed) {
      try {
        garden = new Garden(canvas);
        garden.setSky(stars);
        gardenRef.current = garden;
      } catch {
        setFailed(true);
        return;
      }
    }

    const fit = () => garden?.resize(window.innerWidth, window.innerHeight);
    fit();
    window.addEventListener('resize', fit);
    window.visualViewport?.addEventListener('resize', fit);

    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      let input: FrameInput;
      try {
        input = driver.current(now / 1000);
      } catch (e) {
        console.error(e);
        raf = requestAnimationFrame(loop);
        return;
      }
      if (garden) {
        garden.frame(input, dt);
      } else if (fallbackRef.current) {
        const s = 0.6 + 0.5 * input.fullness;
        fallbackRef.current.style.transform = `translate(-50%, -50%) scale(${s.toFixed(3)})`;
        fallbackRef.current.style.opacity = String((0.25 + 0.6 * input.fullness) * Math.max(0.2, input.presence));
        fallbackRef.current.style.top = `${input.centerY * 100}%`;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', fit);
      window.visualViewport?.removeEventListener('resize', fit);
      gardenRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [failed, driver]);

  return (
    <div className="stage" aria-hidden="true">
      {failed ? <div ref={fallbackRef} className="stage-fallback" /> : <canvas ref={canvasRef} className="stage-canvas" />}
    </div>
  );
}
