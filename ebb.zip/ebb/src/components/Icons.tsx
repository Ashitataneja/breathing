const base = {
  width: 22, height: 22, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor',
  strokeWidth: 1.4, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, 'aria-hidden': true,
};

export const IconPause = () => (
  <svg {...base}><path d="M9 6.5v11M15 6.5v11" /></svg>
);
export const IconPlay = () => (
  <svg {...base}><path d="M8.5 6.2v11.6L18 12z" /></svg>
);
export const IconEnd = () => (
  <svg {...base}><path d="M7 7l10 10M17 7L7 17" /></svg>
);
export const IconSound = () => (
  <svg {...base}><path d="M4.5 9.5h3l4-3.5v12l-4-3.5h-3z" /><path d="M15 9.2a4 4 0 0 1 0 5.6M17.6 7a7 7 0 0 1 0 10" /></svg>
);
export const IconSoundOff = () => (
  <svg {...base}><path d="M4.5 9.5h3l4-3.5v12l-4-3.5h-3z" /><path d="M16 10l4 4M20 10l-4 4" /></svg>
);
export const IconClose = () => (
  <svg {...base}><path d="M7 7l10 10M17 7L7 17" /></svg>
);
