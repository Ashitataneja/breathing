import { isStorageAvailable, SessionRecord } from '../storage/store';
import { dayKey, formatDay, formatMinutesShort, formatTime } from '../lib/format';

interface Props {
  sessions: SessionRecord[];
  onBack: () => void;
  onBegin: () => void;
}

const FEELING_WORD: Record<string, string> = {
  calmer: 'calmer', clearer: 'clearer', same: 'about the same', restless: 'restless', tired: 'tired',
};

/** A quiet record of practice. Consistency is shown, never demanded. */
export function Journey({ sessions, onBack, onBegin }: Props) {
  const total = sessions.reduce((a, s) => a + s.activeSeconds, 0);
  const practiced = new Set(sessions.map((s) => dayKey(s.startedAt)));
  const today = new Date();
  today.setHours(12, 0, 0, 0);
  const days = Array.from({ length: 28 }, (_, i) => {
    const ts = today.getTime() - (27 - i) * 86400000;
    return { ts, on: practiced.has(dayKey(ts)) };
  });
  const recentDays = days.filter((d) => d.on).length;
  const recent = [...sessions].sort((a, b) => b.startedAt - a.startedAt).slice(0, 30);

  return (
    <main className="screen journey">
      <header className="topbar">
        <button className="quiet-link back" onClick={onBack} aria-label="Back to start">← ebb</button>
      </header>

      <section className="journey-body">
        <h1 className="display">Your sky</h1>
        {sessions.length === 0 ? (
          <>
            <p className="lede">Each session you complete leaves a star here. Over time they gather into a sky of your own.</p>
            <button className="begin" onClick={onBegin}>Begin your first breath</button>
          </>
        ) : (
          <>
            <p className="lede">Each star is a moment you gave yourself.</p>
            <dl className="totals">
              <div><dt>Sessions</dt><dd>{sessions.length}</dd></div>
              <div><dt>Time breathing</dt><dd>{formatMinutesShort(total)}</dd></div>
            </dl>

            <div className="weeks">
              <p className="weeks-label">
                The last four weeks · {recentDays === 0 ? 'a fresh start whenever you like' : `${recentDays} ${recentDays === 1 ? 'day' : 'days'} with practice`}
              </p>
              <div className="weeks-grid" role="img" aria-label={`${recentDays} of the last 28 days had a session`}>
                {days.map((d) => (
                  <span key={d.ts} className={`day ${d.on ? 'is-on' : ''}`} title={formatDay(d.ts)} />
                ))}
              </div>
            </div>

            <h2 className="section-title">Recent sessions</h2>
            <ul className="history">
              {recent.map((s) => (
                <li key={s.id}>
                  <span className="h-when">{formatDay(s.startedAt)} <span className="h-time">{formatTime(s.startedAt)}</span></span>
                  <span className="h-len">{formatMinutesShort(s.activeSeconds)}</span>
                  <span className="h-feel">{s.feeling ? `felt ${FEELING_WORD[s.feeling]}` : s.guidance === 'open' ? 'open practice' : ''}</span>
                </li>
              ))}
            </ul>
          </>
        )}
        {!isStorageAvailable() && (
          <p className="notice">This browser isn’t allowing local storage, so your sky will only last for this visit.</p>
        )}
      </section>
    </main>
  );
}
