import { MutableRefObject, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { PHASE_WORD, Phase, easeBreath } from '../breath/pattern';
import { BreathSource, GuidedSource, OpenSource } from '../breath/sources';
import { SessionEngine, SessionResult, SessionStatus } from '../session/SessionEngine';
import type { Ambience } from '../audio/Ambience';
import type { Prefs } from '../storage/store';
import { WakeLock, pulse } from '../lib/platform';
import type { Driver } from './BreathCanvas';
import { IconEnd, IconPause, IconPlay, IconSound, IconSoundOff } from './Icons';

const LEAD_IN = 3.5;
const HIDE_AFTER = 3500;

interface Props {
  prefs: Prefs;
  setPrefs: (p: Partial<Prefs>) => void;
  reducedMotion: boolean;
  driver: MutableRefObject<Driver>;
  /** Fullness of whatever was on screen before, so the lead-in starts from there. */
  lastFullness: MutableRefObject<number>;
  ensureAudio: () => Ambience | null;
  onFinish: (result: SessionResult | null) => void;
}

type Status = 'arriving' | SessionStatus;

export function SessionView({ prefs, setPrefs, reducedMotion, driver, lastFullness, ensureAudio, onFinish }: Props) {
  // A session's settings are fixed when it begins.
  const [config] = useState(() => ({
    guidance: prefs.guidance,
    pattern: prefs.pattern,
    planned: prefs.minutes * 60,
    haptics: prefs.haptics,
  }));
  const engine = useMemo(
    () => new SessionEngine({ plannedSeconds: config.planned, pattern: config.guidance === 'open' ? null : config.pattern }),
    [config],
  );
  const source: BreathSource = useMemo(
    () => (config.guidance === 'open' ? new OpenSource() : new GuidedSource(config.pattern)),
    [config],
  );

  const [status, setStatus] = useState<Status>('arriving');
  const [phase, setPhase] = useState<Phase | null>(null);
  const [cycle, setCycle] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(config.planned);
  const [winding, setWinding] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [sound, setSound] = useState(prefs.sound);
  const [audioMissing, setAudioMissing] = useState(false);

  const progressRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<Ambience | null>(null);
  const hideTimer = useRef<number>();
  const statusRef = useRef<Status>('arriving');
  statusRef.current = status;
  const finished = useRef(false);
  const onFinishRef = useRef(onFinish);
  onFinishRef.current = onFinish;

  // --- audio ---------------------------------------------------------------
  useEffect(() => {
    if (sound) {
      const a = ensureAudio();
      audioRef.current = a;
      if (!a) setAudioMissing(true);
      void a?.setEnabled(true);
    } else {
      void audioRef.current?.setEnabled(false);
    }
  }, [sound, ensureAudio]);
  useEffect(() => () => { void audioRef.current?.setEnabled(false); }, []);

  const soundRef = useRef(sound);
  soundRef.current = sound;
  const toggleSound = useCallback(() => {
    const next = !soundRef.current;
    soundRef.current = next;
    setSound(next);
    setPrefs({ sound: next });
  }, [setPrefs]);

  // --- lifecycle -------------------------------------------------------------
  useEffect(() => {
    const wake = new WakeLock();
    void wake.request();
    const startTimer = window.setTimeout(() => engine.start(), LEAD_IN * 1000);
    const unsub = engine.subscribe(() => {
      setStatus(engine.status);
      if (engine.status === 'complete' && !finished.current) {
        finished.current = true;
        audioRef.current?.chime(0.9);
        wake.release();
        window.setTimeout(() => onFinishRef.current(engine.result), 1400);
      }
    });
    // rAF stops in background tabs; this keeps completion on time regardless.
    const interval = window.setInterval(() => engine.tick(), 1000);
    const onVis = () => engine.tick();
    document.addEventListener('visibilitychange', onVis);
    return () => {
      window.clearTimeout(startTimer);
      window.clearInterval(interval);
      document.removeEventListener('visibilitychange', onVis);
      unsub();
      wake.release();
    };
  }, [engine]);

  // --- per-frame driver --------------------------------------------------------
  const arrivalStart = useRef(performance.now() / 1000);
  const fromFullness = useRef(lastFullness.current);
  const lastPhase = useRef<Phase | null>(null);
  const lastCycle = useRef(-1);
  const lastSecond = useRef(-1);

  useEffect(() => {
    const target0 = source.sample(0).fullness;
    driver.current = (now) => {
      const base = { presence: 1, centerY: 0.46, sky: 0.12, reducedMotion };
      if (engine.status === 'idle') {
        const k = easeBreath(Math.min(1, (now - arrivalStart.current) / LEAD_IN));
        const f = fromFullness.current + (target0 - fromFullness.current) * k;
        lastFullness.current = f;
        return { ...base, fullness: f, phase: null, paused: false };
      }

      engine.tick();
      const t = engine.elapsed();
      const s = source.sample(t);
      lastFullness.current = s.fullness;

      if (s.phase !== lastPhase.current || s.cycle !== lastCycle.current) {
        const phaseChanged = s.phase !== lastPhase.current;
        lastPhase.current = s.phase;
        lastCycle.current = s.cycle;
        if (phaseChanged && engine.status === 'running') {
          setPhase(s.phase);
          setCycle(s.cycle);
          if (config.haptics) {
            if (s.phase === 'inhale') pulse(35);
            else if (s.phase === 'exhale') pulse([12, 90, 12]);
          }
          if (config.guidance === 'quiet' && s.phase === 'inhale') audioRef.current?.chime(0.35);
        }
      }

      const left = Math.max(0, Math.ceil(config.planned - t));
      if (left !== lastSecond.current) {
        lastSecond.current = left;
        setSecondsLeft(left);
        setWinding(engine.isWindingDown());
      }
      if (progressRef.current) progressRef.current.style.transform = `scaleX(${engine.progress().toFixed(4)})`;
      audioRef.current?.setBreath(s.fullness);

      return { ...base, fullness: s.fullness, phase: s.phase, paused: engine.status === 'paused' };
    };
  }, [engine, source, driver, reducedMotion, config, lastFullness]);

  // --- controls ----------------------------------------------------------------
  const end = useCallback(() => {
    if (statusRef.current === 'arriving' || engine.status === 'idle') {
      finished.current = true;
      onFinish(null);
      return;
    }
    engine.end();
  }, [engine, onFinish]);

  const toggle = useCallback(() => engine.toggle(), [engine]);

  const wake = useCallback(() => {
    setControlsVisible(true);
    window.clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => {
      if (statusRef.current === 'running') setControlsVisible(false);
    }, HIDE_AFTER);
  }, []);

  useEffect(() => {
    if (status === 'paused') {
      setControlsVisible(true);
      window.clearTimeout(hideTimer.current);
    } else if (status === 'running') wake();
  }, [status, wake]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const onButton = (e.target as HTMLElement)?.closest?.('button');
      if ((e.key === ' ' || e.key === 'k' || e.key === 'K') && !onButton) {
        e.preventDefault();
        toggle();
      } else if (e.key === 'm' || e.key === 'M') toggleSound();
      else if (e.key === 'Escape') end();
      wake();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [toggle, toggleSound, end, wake]);

  useEffect(() => () => window.clearTimeout(hideTimer.current), []);

  // --- guidance text -------------------------------------------------------------
  let word: string | null = null;
  let wordKey = 'none';
  if (status === 'arriving' || status === 'idle') {
    word = config.guidance === 'open' ? 'Settle in. Breathe at your own pace.' : 'Settle in';
    wordKey = 'arrive';
  } else if (status === 'paused') {
    word = 'Paused';
    wordKey = 'paused';
  } else if (status === 'complete') {
    word = null;
  } else if (config.guidance === 'guided' || (config.guidance === 'quiet' && cycle < 2)) {
    if (phase) {
      word = winding && phase === 'exhale' ? 'One last breath out' : PHASE_WORD[phase];
      wordKey = `${phase}-${cycle}`;
    }
  }

  const mm = Math.floor(secondsLeft / 60);
  const ss = String(secondsLeft % 60).padStart(2, '0');
  const timeText = winding ? 'Finishing this breath' : `${mm}:${ss} left`;

  return (
    <div
      className={`session ${controlsVisible ? 'controls-on' : 'controls-off'} ${status === 'complete' ? 'is-complete' : ''}`}
      onPointerMove={wake}
      onPointerDown={(e) => {
        if ((e.target as HTMLElement).closest('button')) return;
        if (e.pointerType === 'mouse') wake();
        else if (controlsVisible && statusRef.current === 'running') setControlsVisible(false);
        else wake();
      }}
      onFocusCapture={wake}
    >
      <div className="phase-word" aria-live="polite" aria-atomic="true">
        {word && (
          <span key={wordKey} className={`phase-word-text ${status === 'paused' ? 'is-paused' : ''}`}>
            {word}
          </span>
        )}
        {status === 'paused' && <span className="phase-hint">Resume whenever you're ready</span>}
      </div>

      <div className="session-bottom">
        <div className="session-progress" role="progressbar" aria-label="Session progress"
          aria-valuemin={0} aria-valuemax={config.planned} aria-valuenow={config.planned - secondsLeft}
          aria-valuetext={timeText}>
          <div ref={progressRef} className="session-progress-fill" />
        </div>

        <div className="session-controls">
          <button className="icon-btn" onClick={toggleSound} aria-pressed={sound}
            aria-label={sound ? 'Turn sound off (M)' : 'Turn sound on (M)'} title={sound ? 'Sound on' : 'Sound off'}>
            {sound && !audioMissing ? <IconSound /> : <IconSoundOff />}
          </button>
          <button className="icon-btn icon-btn-main" onClick={toggle} disabled={status !== 'running' && status !== 'paused'}
            aria-label={status === 'paused' ? 'Resume (Space)' : 'Pause (Space)'}>
            {status === 'paused' ? <IconPlay /> : <IconPause />}
          </button>
          <button className="icon-btn" onClick={end} aria-label="End session (Esc)" title="End session">
            <IconEnd />
          </button>
        </div>
        <div className="session-time" aria-hidden="true">
          {audioMissing && sound ? 'Sound isn’t available in this browser' : status === 'arriving' || status === 'idle' ? 'Beginning…' : timeText}
        </div>
      </div>
    </div>
  );
}
