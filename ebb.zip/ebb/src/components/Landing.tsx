import { useEffect } from 'react';
import { presetFor } from '../breath/pattern';
import { DURATIONS, Prefs, SessionRecord } from '../storage/store';

interface Props {
  prefs: Prefs;
  setPrefs: (p: Partial<Prefs>) => void;
  sessions: SessionRecord[];
  onBegin: () => void;
  onSettings: () => void;
  onSky: () => void;
}

const fmt = (n: number) => (Number.isInteger(n) ? String(n) : n.toFixed(1));

export function rhythmText(prefs: Prefs) {
  if (prefs.guidance === 'open') return 'Open practice · your own pace';
  const p = prefs.pattern;
  const parts = [`in ${fmt(p.inhale)}`];
  if (p.hold) parts.push(`hold ${fmt(p.hold)}`);
  parts.push(`out ${fmt(p.exhale)}`);
  if (p.rest) parts.push(`rest ${fmt(p.rest)}`);
  const name = presetFor(p)?.name ?? 'Custom';
  return `${name} rhythm · ${parts.join(', ')}${prefs.guidance === 'quiet' ? ' · quiet' : ''}`;
}

export function Landing({ prefs, setPrefs, sessions, onBegin, onSettings, onSky }: Props) {
  const durations = DURATIONS.includes(prefs.minutes) ? DURATIONS : [...DURATIONS, prefs.minutes].sort((a, b) => a - b);
  const count = sessions.length;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Enter' && (e.target as HTMLElement)?.tagName === 'BODY') onBegin();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onBegin]);

  return (
    <main className="screen landing">
      <header className="topbar">
        <span className="wordmark">ebb</span>
        <nav className="topnav" aria-label="Secondary">
          <button className="quiet-link" onClick={onSky}>Your sky</button>
          <button className="quiet-link" onClick={onSettings}>Settings</button>
        </nav>
      </header>

      <section className="landing-body">
        <h1 className="display">Breathe with the light.</h1>
        <p className="lede">
          As it gathers, breathe in. As it softens, let go.
          <br />
          There’s nothing to get right.
        </p>
        {count > 0 && (
          <p className="welcome">
            Welcome back. Your sky holds {count} {count === 1 ? 'star' : 'stars'}.
          </p>
        )}

        <div className="durations" role="radiogroup" aria-label="Session length">
          {durations.map((m) => (
            <button
              key={m}
              role="radio"
              aria-checked={prefs.minutes === m}
              className={`duration ${prefs.minutes === m ? 'is-on' : ''}`}
              onClick={() => setPrefs({ minutes: m })}
            >
              {m}
              <span className="duration-unit"> min</span>
            </button>
          ))}
        </div>

        <button className="begin" onClick={onBegin} autoFocus>
          Begin breathing
        </button>

        <button className="rhythm-note" onClick={onSettings}>
          {rhythmText(prefs)} <span className="rhythm-change">change</span>
        </button>
      </section>
    </main>
  );
}
