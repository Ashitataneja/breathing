import { ReactNode, useEffect, useRef, useState } from 'react';
import { BreathPattern, LIMITS, PRESETS, clampPattern, cycleLength, presetFor } from '../breath/pattern';
import { DURATIONS, Guidance, MotionPref, Prefs, clearHistory } from '../storage/store';
import { audioSupported } from '../audio/Ambience';
import { hapticsSupported, pulse } from '../lib/platform';
import { IconClose } from './Icons';

interface Props {
  prefs: Prefs;
  setPrefs: (p: Partial<Prefs>) => void;
  sessionCount: number;
  onClose: () => void;
}

const GUIDANCE: { id: Guidance; name: string; note: string }[] = [
  { id: 'guided', name: 'Guided', note: 'The light sets the rhythm, with a quiet word for each phase.' },
  { id: 'quiet', name: 'Quiet', note: 'Words for the first two breaths, then only the light (and a soft tone, if sound is on).' },
  { id: 'open', name: 'Open', note: 'No rhythm at all. The light rests and you breathe at your own pace.' },
];

const MOTION: { id: MotionPref; name: string }[] = [
  { id: 'system', name: 'Match system' },
  { id: 'reduced', name: 'Reduced' },
  { id: 'full', name: 'Full' },
];

const fmt = (n: number) => (Number.isInteger(n) ? `${n}` : n.toFixed(1));

export function Settings({ prefs, setPrefs, sessionCount, onClose }: Props) {
  const panelRef = useRef<HTMLDivElement>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const preset = presetFor(prefs.pattern);
  const durations = DURATIONS.includes(prefs.minutes) ? [...DURATIONS, 20] : [...DURATIONS, 20, prefs.minutes].sort((a, b) => a - b);

  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    panelRef.current?.querySelector<HTMLElement>('button, input')?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onClose();
      }
      if (e.key === 'Tab' && panelRef.current) {
        const els = panelRef.current.querySelectorAll<HTMLElement>('button:not([disabled]), input:not([disabled])');
        if (!els.length) return;
        const first = els[0];
        const last = els[els.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => {
      window.removeEventListener('keydown', onKey, true);
      prev?.focus?.();
    };
  }, [onClose]);

  const setPhase = (k: keyof BreathPattern, delta: number) =>
    setPrefs({ pattern: clampPattern({ ...prefs.pattern, [k]: prefs.pattern[k] + delta }) });

  const guidedOff = prefs.guidance === 'open';

  return (
    <div className="sheet-backdrop" onPointerDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="sheet" role="dialog" aria-modal="true" aria-labelledby="settings-title" ref={panelRef}>
        <header className="sheet-head">
          <h2 id="settings-title">Settings</h2>
          <button className="icon-btn" onClick={onClose} aria-label="Close settings"><IconClose /></button>
        </header>

        <Section title="Guidance">
          <div className="options" role="radiogroup" aria-label="Guidance">
            {GUIDANCE.map((g) => (
              <button key={g.id} role="radio" aria-checked={prefs.guidance === g.id}
                className={`option ${prefs.guidance === g.id ? 'is-on' : ''}`} onClick={() => setPrefs({ guidance: g.id })}>
                <span className="option-name">{g.name}</span>
                <span className="option-note">{g.note}</span>
              </button>
            ))}
          </div>
        </Section>

        <Section title="Breathing rhythm" note={guidedOff ? 'Not used in open practice.' : 'Holds are optional. Set them to 0 to breathe without pausing.'}>
          <div className={guidedOff ? 'is-dimmed' : ''}>
            <div className="chips" role="radiogroup" aria-label="Rhythm presets">
              {PRESETS.map((p) => (
                <button key={p.id} role="radio" aria-checked={preset?.id === p.id} disabled={guidedOff}
                  className={`chip ${preset?.id === p.id ? 'is-on' : ''}`} onClick={() => setPrefs({ pattern: p.pattern })} title={p.note}>
                  {p.name}
                </button>
              ))}
              <span className={`chip chip-static ${!preset ? 'is-on' : ''}`} aria-hidden={!!preset}>Custom</span>
            </div>
            <div className="steppers">
              {(['inhale', 'hold', 'exhale', 'rest'] as const).map((k) => (
                <div className="stepper" key={k}>
                  <span className="stepper-label" id={`lbl-${k}`}>
                    {{ inhale: 'Breathe in', hold: 'Hold', exhale: 'Breathe out', rest: 'Rest' }[k]}
                  </span>
                  <div className="stepper-ctrl" role="group" aria-labelledby={`lbl-${k}`}>
                    <button disabled={guidedOff || prefs.pattern[k] <= LIMITS[k].min} onClick={() => setPhase(k, -0.5)}
                      aria-label={`Shorter ${k}`}>−</button>
                    <output aria-live="polite">{fmt(prefs.pattern[k])}<small>s</small></output>
                    <button disabled={guidedOff || prefs.pattern[k] >= LIMITS[k].max} onClick={() => setPhase(k, 0.5)}
                      aria-label={`Longer ${k}`}>+</button>
                  </div>
                </div>
              ))}
            </div>
            <p className="fine">
              One breath takes {fmt(cycleLength(prefs.pattern))} seconds, about {fmt(Math.round((60 / cycleLength(prefs.pattern)) * 10) / 10)} per minute.
            </p>
          </div>
        </Section>

        <Section title="Session length">
          <div className="chips" role="radiogroup" aria-label="Session length">
            {durations.map((m) => (
              <button key={m} role="radio" aria-checked={prefs.minutes === m}
                className={`chip ${prefs.minutes === m ? 'is-on' : ''}`} onClick={() => setPrefs({ minutes: m })}>
                {m} min
              </button>
            ))}
          </div>
        </Section>

        <Section title="Sound, motion & touch">
          <Toggle label="Ambient sound" note={audioSupported() ? 'Soft air and a low drone that follow the breath. Starts only when a session begins.' : 'Audio isn’t supported in this browser.'}
            checked={prefs.sound && audioSupported()} disabled={!audioSupported()} onChange={(v) => setPrefs({ sound: v })} />
          <Toggle label="Gentle vibration" note={hapticsSupported() ? 'A light pulse as each inhale and exhale begins.' : 'Not supported on this device or browser.'}
            checked={prefs.haptics && hapticsSupported()} disabled={!hapticsSupported()}
            onChange={(v) => { setPrefs({ haptics: v }); if (v) pulse(30); }} />
          <div className="row">
            <span className="row-label" id="motion-label">Motion</span>
            <div className="chips" role="radiogroup" aria-labelledby="motion-label">
              {MOTION.map((m) => (
                <button key={m.id} role="radio" aria-checked={prefs.motion === m.id}
                  className={`chip ${prefs.motion === m.id ? 'is-on' : ''}`} onClick={() => setPrefs({ motion: m.id })}>
                  {m.name}
                </button>
              ))}
            </div>
          </div>
        </Section>

        <Section title="About breath detection">
          <p className="fine">
            Ebb doesn’t listen to you or watch you. In every mode the light follows a rhythm you choose. It doesn’t
            measure your breathing. Sensing your breath through the microphone or camera may come later as an
            opt-in experiment, and it would always ask for permission first.
          </p>
        </Section>

        <Section title="Your data">
          <p className="fine">Your settings and sessions stay in this browser. Nothing is sent anywhere.</p>
          {sessionCount > 0 && (
            confirmClear ? (
              <div className="confirm">
                <span>Clear all {sessionCount} sessions and your sky?</span>
                <button className="chip" onClick={() => { clearHistory(); setConfirmClear(false); }}>Clear</button>
                <button className="chip" onClick={() => setConfirmClear(false)}>Keep</button>
              </div>
            ) : (
              <button className="quiet-link danger" onClick={() => setConfirmClear(true)}>Clear session history</button>
            )
          )}
        </Section>
      </div>
    </div>
  );
}

function Section({ title, note, children }: { title: string; note?: string; children: ReactNode }) {
  return (
    <section className="sheet-section">
      <h3>{title}</h3>
      {note && <p className="fine">{note}</p>}
      {children}
    </section>
  );
}

function Toggle({ label, note, checked, disabled, onChange }: { label: string; note: string; checked: boolean; disabled?: boolean; onChange: (v: boolean) => void }) {
  return (
    <button className="toggle" role="switch" aria-checked={checked} disabled={disabled} onClick={() => onChange(!checked)}>
      <span className="toggle-text">
        <span className="toggle-label">{label}</span>
        <span className="option-note">{note}</span>
      </span>
      <span className={`switch ${checked ? 'is-on' : ''}`} aria-hidden="true"><span /></span>
    </button>
  );
}
