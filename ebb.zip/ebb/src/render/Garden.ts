/**
 * The living environment: an atmospheric sky, a slow tide on the horizon,
 * and a luminous organic form surrounded by drifting motes.
 *
 *  inhale  → the form swells and brightens, motes are drawn in to its edge
 *  hold    → everything settles; motion slows but never stops
 *  exhale  → the form softens and contracts, motes drift back out
 *  rest    → quiet, dim, waiting
 *
 * The renderer is stateless with respect to breathing: every frame receives
 * the current breath fullness from the session clock. Internal state is only
 * used for smoothing and for the slow "flow" time that animates texture.
 */

import type { Phase } from '../breath/pattern';

export interface FrameInput {
  fullness: number;
  phase: Phase | null;
  paused: boolean;
  /** 0..1 how present/bright the central form is. */
  presence: number;
  /** Vertical centre of the form as a fraction of height. */
  centerY: number;
  /** 0..1 how much the personal sky (session stars) is emphasised. */
  sky: number;
  reducedMotion: boolean;
}

export interface SkyStar {
  x: number;
  y: number;
  size: number;
  warmth: number;
  /** Index of an earlier star this one is threaded to. */
  link?: number;
}

type RGB = [number, number, number];

const hex = (h: string): RGB => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
const mix = (a: RGB, b: RGB, t: number): RGB => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const rgba = (c: RGB, a: number) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${Math.max(0, Math.min(1, a)).toFixed(3)})`;
const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
const smooth = (e0: number, e1: number, x: number) => {
  const t = clamp01((x - e0) / (e1 - e0));
  return t * t * (3 - 2 * t);
};
/** Frame-rate independent exponential approach. */
const approach = (cur: number, target: number, dt: number, tau: number) => cur + (target - cur) * (1 - Math.exp(-dt / tau));

// Restrained palette: night blues, a hint of dawn, low-saturation tints.
const SKY_TOP_EMPTY = hex('#060914');
const SKY_TOP_FULL = hex('#0d1630');
const SKY_LOW_EMPTY = hex('#10172b');
const SKY_LOW_FULL = hex('#25304d');
const HORIZON_WARM = hex('#3a3350');

const TINT: Record<Phase | 'open', RGB> = {
  inhale: hex('#a6d8d4'),
  hold: hex('#e6d9b8'),
  exhale: hex('#b9b0dc'),
  rest: hex('#8fa3cf'),
  open: hex('#b8c8dc'),
};

/** Deterministic pseudo-random in [0,1). */
function rand(seed: number) {
  const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
}

interface Mote {
  angle: number;
  field: number;
  rim: number;
  offset: number;
  size: number;
  speed: number;
  phase: number;
}

interface Dust {
  x: number;
  y: number;
  size: number;
  tw: number;
}

export class Garden {
  private ctx: CanvasRenderingContext2D;
  private w = 1;
  private h = 1;
  private dpr = 1;
  private flow = 0;
  private sprite: HTMLCanvasElement;
  private motes: Mote[] = [];
  private dust: Dust[] = [];
  private stars: SkyStar[] = [];

  // smoothed state
  private f = 0.3;
  private still = 0;
  private presence = 0;
  private centerY = 0.45;
  private sky = 0;
  private tint: RGB = TINT.open;
  private pausedDim = 0;

  constructor(private canvas: HTMLCanvasElement) {
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('Canvas 2D is not supported');
    this.ctx = ctx;
    this.sprite = this.makeSprite();
  }

  resize(cssW: number, cssH: number) {
    const area = cssW * cssH;
    this.dpr = Math.min(window.devicePixelRatio || 1, area > 1_400_000 ? 1.5 : 2);
    this.w = Math.max(1, cssW);
    this.h = Math.max(1, cssH);
    this.canvas.width = Math.round(this.w * this.dpr);
    this.canvas.height = Math.round(this.h * this.dpr);
    this.seed(area < 500_000 ? 110 : 170);
  }

  setSky(stars: SkyStar[]) {
    this.stars = stars;
  }

  private seed(count: number) {
    this.motes = Array.from({ length: count }, (_, i) => ({
      angle: rand(i + 1) * Math.PI * 2,
      field: 1.5 + Math.pow(rand(i + 101), 0.8) * 2.9,
      rim: 0.8 + Math.pow(rand(i + 201), 1.5) * 0.45,
      offset: rand(i + 301),
      size: 0.5 + Math.pow(rand(i + 401), 2) * 1.5,
      speed: (rand(i + 501) - 0.5) * 2,
      phase: rand(i + 601) * Math.PI * 2,
    }));
    this.dust = Array.from({ length: 90 }, (_, i) => ({
      x: rand(i + 1001),
      y: Math.pow(rand(i + 1101), 1.4) * 0.78,
      size: 0.3 + rand(i + 1201) * 0.7,
      tw: rand(i + 1301) * Math.PI * 2,
    }));
  }

  private makeSprite() {
    const s = document.createElement('canvas');
    s.width = s.height = 64;
    const g = s.getContext('2d')!;
    const grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    grad.addColorStop(0, 'rgba(255,248,236,1)');
    grad.addColorStop(0.18, 'rgba(255,244,228,0.75)');
    grad.addColorStop(0.5, 'rgba(240,236,255,0.16)');
    grad.addColorStop(1, 'rgba(240,236,255,0)');
    g.fillStyle = grad;
    g.fillRect(0, 0, 64, 64);
    return s;
  }

  frame(input: FrameInput, rawDt: number) {
    const dt = Math.min(0.1, Math.max(0, rawDt));
    const rm = input.reducedMotion;

    // --- smoothing ----------------------------------------------------------
    this.f = approach(this.f, clamp01(input.fullness), dt, 0.18);
    const stillTarget = input.paused || input.phase === 'hold' || input.phase === 'rest' ? 1 : 0;
    this.still = approach(this.still, stillTarget, dt, 0.9);
    this.presence = approach(this.presence, input.presence, dt, 1.4);
    this.centerY = approach(this.centerY, input.centerY, dt, 1.2);
    this.sky = approach(this.sky, input.sky, dt, 1.2);
    this.pausedDim = approach(this.pausedDim, input.paused ? 1 : 0, dt, 0.8);
    const tt = TINT[input.phase ?? 'open'];
    const k = 1 - Math.exp(-dt / 1.3);
    this.tint = mix(this.tint, tt, k);

    const speed = (rm ? 0.12 : 1) * (1 - 0.72 * this.still) * (1 - 0.5 * this.pausedDim);
    this.flow += dt * speed;

    const { ctx, w, h, dpr } = this;
    const f = this.f;
    const glow = (0.55 + 0.45 * f) * (1 - 0.35 * this.pausedDim);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.globalCompositeOperation = 'source-over';

    // --- sky ----------------------------------------------------------------
    const sf = f * this.presence;
    const bg = ctx.createLinearGradient(0, 0, 0, h);
    bg.addColorStop(0, rgba(mix(SKY_TOP_EMPTY, SKY_TOP_FULL, sf * 0.8), 1));
    bg.addColorStop(0.62, rgba(mix(SKY_LOW_EMPTY, SKY_LOW_FULL, sf * 0.7), 1));
    bg.addColorStop(1, rgba(mix(SKY_LOW_EMPTY, HORIZON_WARM, 0.35 + sf * 0.4), 1));
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    const m = Math.min(w, h);
    const cx = w / 2;
    const cy = h * this.centerY;

    // atmospheric bloom behind the form
    ctx.globalCompositeOperation = 'lighter';
    const halo = ctx.createRadialGradient(cx, cy, 0, cx, cy, m * (0.75 + 0.2 * f));
    halo.addColorStop(0, rgba(this.tint, 0.07 + 0.09 * f * this.presence));
    halo.addColorStop(1, rgba(this.tint, 0));
    ctx.fillStyle = halo;
    ctx.fillRect(0, 0, w, h);

    this.drawDust(input);
    this.drawStars();
    this.drawTide(f);
    this.drawForm(cx, cy, m, f, glow, rm);
    if (!rm || this.presence > 0) this.drawMotes(cx, cy, m, f, rm);

    ctx.globalCompositeOperation = 'source-over';
  }

  private drawDust(input: FrameInput) {
    const { ctx, w, h } = this;
    const t = this.flow;
    const base = 0.16 + 0.14 * this.sky;
    for (const d of this.dust) {
      const tw = input.reducedMotion ? 0.7 : 0.55 + 0.45 * Math.sin(t * 0.6 + d.tw);
      ctx.fillStyle = `rgba(214,222,245,${(base * tw).toFixed(3)})`;
      const s = d.size;
      ctx.fillRect(d.x * w - s / 2, d.y * h - s / 2, s, s);
    }
  }

  private drawStars() {
    if (!this.stars.length) return;
    const { ctx, w, h } = this;
    const emph = 0.45 + 0.55 * this.sky;
    // Faint threads between consecutive stars: the constellation you've made.
    if (this.stars.length > 1 && this.sky > 0.02) {
      ctx.strokeStyle = `rgba(220,214,240,${(0.08 * this.sky).toFixed(3)})`;
      ctx.lineWidth = 0.6;
      ctx.beginPath();
      for (const s of this.stars) {
        if (s.link === undefined) continue;
        const o = this.stars[s.link];
        ctx.moveTo(o.x * w, o.y * h);
        ctx.lineTo(s.x * w, s.y * h);
      }
      ctx.stroke();
    }
    this.stars.forEach((s, i) => {
      const tw = 0.82 + 0.18 * Math.sin(this.flow * 0.45 + i * 1.7);
      const r = (5 + s.size * 6) * (0.8 + 0.3 * this.sky);
      ctx.globalAlpha = Math.min(1, 0.55 * emph * tw);
      ctx.drawImage(this.sprite, s.x * w - r, s.y * h - r, r * 2, r * 2);
    });
    ctx.globalAlpha = 1;
  }

  private drawTide(f: number) {
    const { ctx, w, h } = this;
    const t = this.flow;
    for (let i = 0; i < 3; i++) {
      const baseY = h * (0.8 + i * 0.065) - f * h * 0.022 * (1 - i * 0.3);
      const amp = h * (0.012 + i * 0.004);
      ctx.beginPath();
      ctx.moveTo(0, h);
      for (let x = 0; x <= w + 8; x += 8) {
        const u = x / w;
        const y =
          baseY +
          amp * Math.sin(u * 5.1 + t * (0.11 + i * 0.03) + i * 2.1) +
          amp * 0.6 * Math.sin(u * 11.3 - t * (0.07 + i * 0.02) + i) +
          amp * 0.3 * Math.sin(u * 23.7 + t * 0.05);
        ctx.lineTo(x, y);
      }
      ctx.lineTo(w, h);
      ctx.closePath();
      const g = ctx.createLinearGradient(0, baseY - amp * 2, 0, h);
      g.addColorStop(0, rgba(this.tint, 0.035 + 0.025 * f));
      g.addColorStop(1, rgba(this.tint, 0));
      ctx.fillStyle = g;
      ctx.fill();
    }
  }

  private drawForm(cx: number, cy: number, m: number, f: number, glow: number, rm: boolean) {
    const p = this.presence;
    if (p < 0.01) return;
    const { ctx } = this;
    const t = this.flow;
    const R0 = m * 0.17;
    const swell = rm ? 0.78 + 0.3 * f : 0.6 + 0.55 * f;
    const R = R0 * swell * (0.7 + 0.3 * p);
    const wob = (rm ? 0.02 : 0.075) * (1 - 0.55 * this.still);
    const N = 120;
    const layers = 6;

    for (let k = layers - 1; k >= 0; k--) {
      const lr = R * (1 + k * 0.16);
      const kk = k * 1.37;
      ctx.beginPath();
      for (let i = 0; i <= N; i++) {
        const a = (i / N) * Math.PI * 2;
        const n =
          Math.sin(a * 2 + t * 0.31 + kk) * 0.5 +
          Math.sin(a * 3 - t * 0.23 + kk * 1.9) * 0.32 +
          Math.sin(a * 5 + t * 0.41 - kk * 0.7) * 0.18 +
          Math.sin(a * 7 - t * 0.17 + kk * 2.3) * 0.1;
        const r = lr * (1 + wob * (1 + k * 0.35) * n);
        const x = cx + Math.cos(a) * r;
        const y = cy + Math.sin(a) * r * 0.97;
        i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
      ctx.closePath();
      const g = ctx.createRadialGradient(cx, cy - R * 0.1, lr * 0.05, cx, cy, lr * 1.1);
      const a0 = (0.11 - k * 0.012) * glow * p;
      g.addColorStop(0, rgba(this.tint, a0 * 1.6));
      g.addColorStop(0.6, rgba(this.tint, a0));
      g.addColorStop(1, rgba(this.tint, 0));
      ctx.fillStyle = g;
      ctx.fill();
      if (k === 0 || k === 2) {
        ctx.strokeStyle = rgba(this.tint, (k === 0 ? 0.16 : 0.06) * glow * p);
        ctx.lineWidth = k === 0 ? 1 : 0.8;
        ctx.stroke();
      }
    }

    // a soft inner core
    const core = ctx.createRadialGradient(cx, cy - R * 0.08, 0, cx, cy, R * 0.9);
    core.addColorStop(0, `rgba(255,250,240,${(0.14 + 0.2 * f) * glow * p})`);
    core.addColorStop(0.45, rgba(this.tint, 0.08 * glow * p));
    core.addColorStop(1, rgba(this.tint, 0));
    ctx.fillStyle = core;
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, Math.PI * 2);
    ctx.fill();
  }

  private drawMotes(cx: number, cy: number, m: number, f: number, rm: boolean) {
    const { ctx } = this;
    const t = this.flow;
    const p = this.presence;
    const R0 = m * 0.17;
    const R = R0 * (0.6 + 0.55 * f) * (0.7 + 0.3 * p);
    for (const mo of this.motes) {
      // Staggered gathering: each mote joins the form at its own moment.
      const g = smooth(0, 1, (f - mo.offset * 0.35) / 0.65);
      const wander = (1 - g) * (rm ? 0 : 0.35);
      const ang = mo.angle + t * 0.035 * mo.speed + wander * Math.sin(t * 0.2 + mo.phase);
      const far = mo.field * R0 * (1 + 0.06 * Math.sin(t * 0.3 + mo.phase));
      // At rest on the form, motes still drift slightly in and out of its edge.
      const near = R * mo.rim * (1 + 0.05 * Math.sin(t * 0.5 + mo.phase * 3));
      const r = far + (near - far) * g;
      const x = cx + Math.cos(ang) * r;
      const y = cy + Math.sin(ang) * r * 0.97;
      const size = mo.size * (1.6 + 1.4 * g) * 2.2;
      ctx.globalAlpha = (0.2 + 0.42 * g) * (0.35 + 0.65 * p) * (1 - 0.3 * this.pausedDim);
      ctx.drawImage(this.sprite, x - size, y - size, size * 2, size * 2);
    }
    ctx.globalAlpha = 1;
  }
}

/** Place a star for each completed session. Deterministic, so the sky is stable across visits. */
export function skyFromSessions(sessions: { startedAt: number; activeSeconds: number }[]): SkyStar[] {
  const out: SkyStar[] = [];
  sessions.slice(-160).forEach((s, i) => {
    const seed = Math.floor(s.startedAt / 1000) % 100000;
    // Low-discrepancy placement keeps stars spread out across the upper sky.
    let x = 0.07 + 0.86 * ((i * 0.6180339 + rand(seed) * 0.12) % 1);
    let y = 0.06 + 0.42 * ((i * 0.4142135 + rand(seed + 1) * 0.2) % 1);
    // Keep clear of the central form.
    const dx = (x - 0.5) / 0.24;
    const dy = (y - 0.44) / 0.22;
    if (dx * dx + dy * dy < 1) y = Math.max(0.05, 0.44 - 0.22 * Math.sqrt(Math.max(0, 1 - dx * dx)) - 0.03);
    // Thread to the nearest earlier star, if it's close enough.
    let link: number | undefined;
    let best = 0.05;
    out.forEach((o, j) => {
      const d = (o.x - x) ** 2 + (o.y - y) ** 2;
      if (d < best) { best = d; link = j; }
    });
    x = Math.min(0.96, Math.max(0.04, x));
    out.push({ x, y, size: Math.min(1, s.activeSeconds / 900), warmth: rand(seed + 3), link });
  });
  return out;
}
