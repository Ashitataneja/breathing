/**
 * The breathing-session state machine.
 *
 *            start()            pause()
 *   idle ───────────▶ running ◀─────────▶ paused
 *                       │   resume()        │
 *                       │ tick(): planned   │ end()
 *                       │ time reached and  │
 *                       │ the breath cycle  │
 *                       ▼ has finished      ▼
 *                    complete ◀──────────── (any)
 *
 * Time is measured from a monotonic clock and accumulated only while
 * running, so the session is correct even if no frame is drawn for minutes
 * (background tab, locked phone). Visuals ask `elapsed()` every frame.
 */

import { BreathPattern, cycleLength, secondsToCycleEnd } from '../breath/pattern';

export type SessionStatus = 'idle' | 'running' | 'paused' | 'complete';

export interface SessionConfig {
  /** Planned length in seconds. */
  plannedSeconds: number;
  /** When set, the session finishes at the end of a breath rather than mid-breath. */
  pattern: BreathPattern | null;
}

export interface SessionResult {
  plannedSeconds: number;
  activeSeconds: number;
  /** True when the planned time was reached (not ended early). */
  reachedPlanned: boolean;
  breaths: number;
  startedAt: number;
}

export type Clock = () => number;
const defaultClock: Clock = () => performance.now() / 1000;

export class SessionEngine {
  private status_: SessionStatus = 'idle';
  private accumulated = 0;
  private runningSince = 0;
  private startedAtWall = 0;
  private result_: SessionResult | null = null;
  private listeners = new Set<() => void>();
  /** Active time at which the session closes (after finishing the last breath). */
  readonly closeAt: number;

  constructor(readonly config: SessionConfig, private clock: Clock = defaultClock) {
    const { plannedSeconds, pattern } = config;
    if (pattern) {
      const toEnd = secondsToCycleEnd(pattern, plannedSeconds);
      this.closeAt = plannedSeconds + (toEnd >= cycleLength(pattern) - 1e-6 ? 0 : toEnd);
    } else {
      this.closeAt = plannedSeconds;
    }
  }

  get status() { return this.status_; }
  get result() { return this.result_; }

  /** Seconds of active (unpaused) time. */
  elapsed(): number {
    if (this.status_ === 'running') return this.accumulated + (this.clock() - this.runningSince);
    return this.accumulated;
  }

  /** 0..1 against the planned length (not the closing breath). */
  progress(): number {
    return Math.min(1, this.elapsed() / this.config.plannedSeconds);
  }

  /** True once planned time has passed and we are finishing the final breath. */
  isWindingDown(): boolean {
    return this.elapsed() >= this.config.plannedSeconds;
  }

  start() {
    if (this.status_ !== 'idle') return;
    this.startedAtWall = Date.now();
    this.runningSince = this.clock();
    this.set('running');
  }

  pause() {
    if (this.status_ !== 'running') return;
    this.accumulated += this.clock() - this.runningSince;
    this.set('paused');
  }

  resume() {
    if (this.status_ !== 'paused') return;
    this.runningSince = this.clock();
    this.set('running');
  }

  toggle() {
    if (this.status_ === 'running') this.pause();
    else if (this.status_ === 'paused') this.resume();
  }

  /** Call regularly (every frame and on a coarse interval). Completes when due. */
  tick() {
    if (this.status_ === 'running' && this.elapsed() >= this.closeAt) this.finish(true);
  }

  /** End now, at the user's request. */
  end() {
    if (this.status_ === 'idle' || this.status_ === 'complete') return;
    this.finish(this.elapsed() >= this.config.plannedSeconds);
  }

  subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private finish(reachedPlanned: boolean) {
    if (this.status_ === 'running') this.accumulated += this.clock() - this.runningSince;
    // If the tab slept past the end, don't count time beyond the closing breath.
    const active = Math.min(this.accumulated, this.closeAt);
    this.accumulated = active;
    const pattern = this.config.pattern;
    this.result_ = {
      plannedSeconds: this.config.plannedSeconds,
      activeSeconds: active,
      reachedPlanned,
      breaths: pattern ? Math.floor(active / cycleLength(pattern) + 0.25) : 0,
      startedAt: this.startedAtWall,
    };
    this.set('complete');
  }

  private set(s: SessionStatus) {
    this.status_ = s;
    this.listeners.forEach((fn) => fn());
  }
}
