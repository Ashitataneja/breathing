import { describe, expect, it } from 'vitest';
import { clampPattern, cycleLength, sampleBreath, secondsToCycleEnd } from '../breath/pattern';
import { SessionEngine } from '../session/SessionEngine';

const gentle = { inhale: 4, hold: 2, exhale: 6, rest: 0 };

describe('sampleBreath', () => {
  it('walks through inhale → hold → exhale with continuous fullness', () => {
    expect(sampleBreath(gentle, 0)).toMatchObject({ phase: 'inhale', fullness: 0, cycle: 0 });
    expect(sampleBreath(gentle, 2).fullness).toBeCloseTo(0.5);
    expect(sampleBreath(gentle, 4.5)).toMatchObject({ phase: 'hold', fullness: 1 });
    expect(sampleBreath(gentle, 9).phase).toBe('exhale');
    expect(sampleBreath(gentle, 9).fullness).toBeCloseTo(0.5);
    expect(sampleBreath(gentle, 12)).toMatchObject({ phase: 'inhale', cycle: 1 });
    // no jumps across phase boundaries
    for (let t = 0.01; t < 24; t += 0.01) {
      expect(Math.abs(sampleBreath(gentle, t).fullness - sampleBreath(gentle, t - 0.01).fullness)).toBeLessThan(0.02);
    }
  });

  it('skips holds set to zero', () => {
    const p = { inhale: 4, hold: 0, exhale: 6, rest: 0 };
    expect(sampleBreath(p, 4).phase).toBe('exhale');
  });

  it('clamps out-of-range timings', () => {
    expect(clampPattern({ inhale: 0, hold: -3, exhale: 99, rest: NaN })).toEqual({ inhale: 2, hold: 0, exhale: 12, rest: 0 });
  });

  it('computes time to the end of the cycle', () => {
    expect(secondsToCycleEnd(gentle, 10)).toBe(2);
    expect(cycleLength(gentle)).toBe(12);
  });
});

describe('SessionEngine', () => {
  const clock = () => {
    let t = 1000;
    return { now: () => t, advance: (s: number) => { t += s; } };
  };

  it('accumulates time only while running', () => {
    const c = clock();
    const e = new SessionEngine({ plannedSeconds: 60, pattern: gentle }, c.now);
    e.start();
    c.advance(10);
    expect(e.elapsed()).toBe(10);
    e.pause();
    c.advance(100);
    expect(e.elapsed()).toBe(10);
    e.tick();
    expect(e.status).toBe('paused');
    e.resume();
    c.advance(5);
    expect(e.elapsed()).toBe(15);
  });

  it('finishes at the end of a breath, not mid-breath', () => {
    const c = clock();
    // 65s planned with a 12s cycle → closes at 72s
    const e = new SessionEngine({ plannedSeconds: 65, pattern: gentle }, c.now);
    expect(e.closeAt).toBe(72);
    e.start();
    c.advance(66);
    e.tick();
    expect(e.status).toBe('running');
    expect(e.isWindingDown()).toBe(true);
    c.advance(6);
    e.tick();
    expect(e.status).toBe('complete');
    expect(e.result).toMatchObject({ reachedPlanned: true, activeSeconds: 72, breaths: 6 });
  });

  it('does not extend when planned time lands on a cycle boundary', () => {
    expect(new SessionEngine({ plannedSeconds: 120, pattern: gentle }).closeAt).toBe(120);
  });

  it('caps time when a background tab sleeps past the end', () => {
    const c = clock();
    const e = new SessionEngine({ plannedSeconds: 120, pattern: null }, c.now);
    e.start();
    c.advance(1000);
    e.tick();
    expect(e.result?.activeSeconds).toBe(120);
  });

  it('records early ends honestly and notifies listeners', () => {
    const c = clock();
    const e = new SessionEngine({ plannedSeconds: 300, pattern: gentle }, c.now);
    const seen: string[] = [];
    e.subscribe(() => seen.push(e.status));
    e.start();
    c.advance(40);
    e.end();
    expect(seen).toEqual(['running', 'complete']);
    expect(e.result).toMatchObject({ reachedPlanned: false, activeSeconds: 40 });
    e.resume();
    expect(e.status).toBe('complete');
  });
});
