import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BreathCanvas, Driver } from './components/BreathCanvas';
import { Landing } from './components/Landing';
import { SessionView } from './components/SessionView';
import { Completion } from './components/Completion';
import { Journey } from './components/Journey';
import { Settings } from './components/Settings';
import { GuidedSource } from './breath/sources';
import { skyFromSessions } from './render/Garden';
import { Ambience } from './audio/Ambience';
import { SessionResult } from './session/SessionEngine';
import { SessionRecord, addSession, usePrefs, useSessions } from './storage/store';
import { useReducedMotion } from './lib/useReducedMotion';

type Screen = 'landing' | 'session' | 'complete' | 'journey';

/** Sessions shorter than this aren't recorded. */
const MIN_RECORDED_SECONDS = 15;

const portrait = () => window.innerHeight > window.innerWidth * 1.1;

export default function App() {
  const [prefs, setPrefs] = usePrefs();
  const sessions = useSessions();
  const reducedMotion = useReducedMotion(prefs.motion);
  const [screen, setScreen] = useState<Screen>('landing');
  const [visible, setVisible] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [last, setLast] = useState<{ record: SessionRecord; reachedPlanned: boolean } | null>(null);
  const [sessionKey, setSessionKey] = useState(0);

  const stars = useMemo(() => skyFromSessions(sessions), [sessions]);
  const lastFullness = useRef(0.3);
  const reducedRef = useRef(reducedMotion);
  reducedRef.current = reducedMotion;

  // --- ambience: created lazily from a user gesture --------------------------
  const ambience = useRef<Ambience | null | undefined>(undefined);
  const ensureAudio = useCallback(() => {
    if (ambience.current === undefined) ambience.current = Ambience.create();
    return ambience.current;
  }, []);
  useEffect(() => () => ambience.current?.dispose(), []);

  // --- the canvas driver for non-session screens -----------------------------
  const patternRef = useRef(prefs.pattern);
  patternRef.current = prefs.pattern;
  const preview = useMemo(() => new GuidedSource(prefs.pattern), []); // eslint-disable-line react-hooks/exhaustive-deps
  const ambientDriver = useCallback(
    (kind: Exclude<Screen, 'session'>): Driver => {
      const t0 = performance.now() / 1000;
      return (now) => {
        preview.pattern = patternRef.current;
        const s = preview.sample(now - t0);
        // Off-session screens breathe more faintly, so they never demand attention.
        const depth = kind === 'landing' ? 0.85 : kind === 'complete' ? 0.5 : 0.35;
        const f = 0.15 + s.fullness * depth;
        lastFullness.current = f;
        const p = portrait();
        return {
          fullness: f,
          phase: kind === 'landing' ? s.phase : null,
          paused: false,
          presence: kind === 'landing' ? 0.8 : kind === 'complete' ? 0.38 : 0.18,
          centerY: kind === 'landing' ? (p ? 0.3 : 0.36) : kind === 'complete' ? (p ? 0.17 : 0.2) : 0.62,
          sky: kind === 'landing' ? 0.45 : kind === 'complete' ? 0.7 : 1,
          reducedMotion: reducedRef.current,
        };
      };
    },
    [preview],
  );
  const driver = useRef<Driver>(null as unknown as Driver);
  if (!driver.current) driver.current = ambientDriver('landing');

  // --- navigation with a quiet cross-fade -------------------------------------
  const timer = useRef<number>();
  const go = useCallback(
    (next: Screen) => {
      setVisible(false);
      window.clearTimeout(timer.current);
      timer.current = window.setTimeout(() => {
        if (next !== 'session') driver.current = ambientDriver(next);
        else setSessionKey((k) => k + 1);
        setScreen(next);
        setVisible(true);
        window.scrollTo(0, 0);
      }, reducedRef.current ? 150 : 550);
    },
    [ambientDriver],
  );

  const begin = useCallback(() => {
    ensureAudio(); // inside the click, so browsers allow sound later
    setSettingsOpen(false);
    go('session');
  }, [go, ensureAudio]);

  const finish = useCallback(
    (result: SessionResult | null) => {
      if (!result || result.activeSeconds < MIN_RECORDED_SECONDS) {
        go('landing');
        return;
      }
      const rec: Omit<SessionRecord, 'id'> = {
        startedAt: result.startedAt,
        activeSeconds: Math.round(result.activeSeconds),
        plannedSeconds: result.plannedSeconds,
        guidance: prefs.guidance,
        breaths: result.breaths,
      };
      const id = addSession(rec);
      setLast({ record: { ...rec, id }, reachedPlanned: result.reachedPlanned });
      go('complete');
    },
    [go, prefs.guidance],
  );

  return (
    <>
      <BreathCanvas driver={driver} stars={stars} />
      <div className={`layer ${visible ? 'is-visible' : 'is-hidden'} ${reducedMotion ? 'reduced' : ''}`}>
        {screen === 'landing' && (
          <Landing prefs={prefs} setPrefs={setPrefs} sessions={sessions} onBegin={begin}
            onSettings={() => setSettingsOpen(true)} onSky={() => go('journey')} />
        )}
        {screen === 'session' && (
          <SessionView key={sessionKey} prefs={prefs} setPrefs={setPrefs} reducedMotion={reducedMotion} driver={driver}
            lastFullness={lastFullness} ensureAudio={ensureAudio} onFinish={finish} />
        )}
        {screen === 'complete' && last && (
          <Completion record={sessions.find((s) => s.id === last.record.id) ?? last.record} reachedPlanned={last.reachedPlanned}
            totalSessions={sessions.length} onAgain={begin} onDone={() => go('landing')} onSky={() => go('journey')} />
        )}
        {screen === 'journey' && <Journey sessions={sessions} onBack={() => go('landing')} onBegin={begin} />}
      </div>
      {settingsOpen && screen !== 'session' && (
        <Settings prefs={prefs} setPrefs={setPrefs} sessionCount={sessions.length} onClose={() => setSettingsOpen(false)} />
      )}
    </>
  );
}
