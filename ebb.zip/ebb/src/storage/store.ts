/**
 * Local-only persistence for preferences and session history.
 * Nothing leaves the device. If storage is unavailable (private mode,
 * blocked site data) everything still works in memory for this visit.
 */

import { useSyncExternalStore } from 'react';
import { BreathPattern, PRESETS, clampPattern } from '../breath/pattern';

export type Guidance = 'guided' | 'quiet' | 'open';
export type MotionPref = 'system' | 'reduced' | 'full';

export interface Prefs {
  pattern: BreathPattern;
  minutes: number;
  sound: boolean;
  motion: MotionPref;
  haptics: boolean;
  guidance: Guidance;
}

export type Feeling = 'calmer' | 'clearer' | 'same' | 'restless' | 'tired';

export interface SessionRecord {
  id: string;
  startedAt: number;
  activeSeconds: number;
  plannedSeconds: number;
  guidance: Guidance;
  breaths: number;
  feeling?: Feeling;
}

export const DURATIONS = [2, 5, 10, 15];

export const DEFAULT_PREFS: Prefs = {
  pattern: PRESETS[0].pattern,
  minutes: 5,
  sound: false,
  motion: 'system',
  haptics: false,
  guidance: 'guided',
};

const KEY_PREFS = 'ebb.prefs.v1';
const KEY_SESSIONS = 'ebb.sessions.v1';

let storageOk = true;

function read<T>(key: string): T | undefined {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : undefined;
  } catch {
    storageOk = false;
    return undefined;
  }
}

function write(key: string, value: unknown) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
    storageOk = true;
  } catch {
    storageOk = false;
  }
}

export function isStorageAvailable() {
  return storageOk;
}

function sanitizePrefs(p: Partial<Prefs> | undefined): Prefs {
  const merged = { ...DEFAULT_PREFS, ...(p ?? {}) };
  return {
    pattern: clampPattern({ ...DEFAULT_PREFS.pattern, ...(merged.pattern ?? {}) }),
    minutes: Math.min(60, Math.max(1, Math.round(Number(merged.minutes) || DEFAULT_PREFS.minutes))),
    sound: !!merged.sound,
    motion: (['system', 'reduced', 'full'] as const).includes(merged.motion) ? merged.motion : 'system',
    haptics: !!merged.haptics,
    guidance: (['guided', 'quiet', 'open'] as const).includes(merged.guidance) ? merged.guidance : 'guided',
  };
}

function sanitizeSessions(list: unknown): SessionRecord[] {
  if (!Array.isArray(list)) return [];
  return list.filter(
    (s): s is SessionRecord =>
      !!s && typeof s === 'object' && typeof s.id === 'string' && Number.isFinite(s.startedAt) && Number.isFinite(s.activeSeconds),
  );
}

// --- tiny observable stores -------------------------------------------------

function createStore<T>(initial: T, persist: (v: T) => void) {
  let value = initial;
  const subs = new Set<() => void>();
  return {
    get: () => value,
    set(next: T) {
      value = next;
      persist(next);
      subs.forEach((f) => f());
    },
    subscribe(f: () => void) {
      subs.add(f);
      return () => { subs.delete(f); };
    },
  };
}

export const prefsStore = createStore<Prefs>(sanitizePrefs(read<Partial<Prefs>>(KEY_PREFS)), (v) => write(KEY_PREFS, v));
export const sessionsStore = createStore<SessionRecord[]>(sanitizeSessions(read(KEY_SESSIONS)), (v) => write(KEY_SESSIONS, v));

const setPrefs = (patch: Partial<Prefs>) => prefsStore.set(sanitizePrefs({ ...prefsStore.get(), ...patch }));

export function usePrefs(): [Prefs, (patch: Partial<Prefs>) => void] {
  return [useSyncExternalStore(prefsStore.subscribe, prefsStore.get), setPrefs];
}

export function useSessions(): SessionRecord[] {
  return useSyncExternalStore(sessionsStore.subscribe, sessionsStore.get);
}

export function addSession(rec: Omit<SessionRecord, 'id'>): string {
  const id = `${rec.startedAt.toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
  sessionsStore.set([...sessionsStore.get(), { ...rec, id }].slice(-500));
  return id;
}

export function updateSession(id: string, patch: Partial<SessionRecord>) {
  sessionsStore.set(sessionsStore.get().map((s) => (s.id === id ? { ...s, ...patch } : s)));
}

export function clearHistory() {
  sessionsStore.set([]);
}
