import { useEffect, useState } from 'react';
import type { MotionPref } from '../storage/store';

export function useReducedMotion(pref: MotionPref): boolean {
  const [system, setSystem] = useState(() =>
    typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches,
  );
  useEffect(() => {
    const mq = window.matchMedia?.('(prefers-reduced-motion: reduce)');
    if (!mq) return;
    const on = () => setSystem(mq.matches);
    mq.addEventListener?.('change', on);
    return () => mq.removeEventListener?.('change', on);
  }, []);
  return pref === 'reduced' ? true : pref === 'full' ? false : system;
}
