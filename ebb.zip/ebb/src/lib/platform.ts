/** Small wrappers around optional browser features. All fail quietly. */

export function hapticsSupported(): boolean {
  return typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function';
}

export function pulse(pattern: number | number[]) {
  if (!hapticsSupported()) return;
  try { navigator.vibrate(pattern); } catch { /* ignore */ }
}

type Sentinel = { release(): Promise<void> };

/** Keeps the screen awake during a session where supported. */
export class WakeLock {
  private sentinel: Sentinel | null = null;
  private wanted = false;
  private onVis = () => { if (this.wanted && document.visibilityState === 'visible') void this.acquire(); };

  async request() {
    this.wanted = true;
    document.addEventListener('visibilitychange', this.onVis);
    await this.acquire();
  }

  private async acquire() {
    const wl = (navigator as unknown as { wakeLock?: { request(t: 'screen'): Promise<Sentinel> } }).wakeLock;
    if (!wl || this.sentinel) return;
    try {
      this.sentinel = await wl.request('screen');
      (this.sentinel as unknown as EventTarget).addEventListener?.('release', () => { this.sentinel = null; });
    } catch { /* not allowed or unsupported */ }
  }

  release() {
    this.wanted = false;
    document.removeEventListener('visibilitychange', this.onVis);
    void this.sentinel?.release().catch(() => {});
    this.sentinel = null;
  }
}

export function canvasSupported(): boolean {
  try {
    return !!document.createElement('canvas').getContext('2d');
  } catch {
    return false;
  }
}
