export function formatDuration(seconds: number): string {
  const s = Math.max(0, Math.round(seconds));
  if (s < 60) return `${s} second${s === 1 ? '' : 's'}`;
  const m = Math.floor(s / 60);
  const r = s % 60;
  const mm = `${m} minute${m === 1 ? '' : 's'}`;
  return r >= 10 ? `${mm} ${r} seconds` : mm;
}

export function formatMinutesShort(seconds: number): string {
  const m = seconds / 60;
  if (m < 1) return `${Math.round(seconds)}s`;
  if (m < 60) return `${Math.round(m)} min`;
  const h = Math.floor(m / 60);
  const rm = Math.round(m % 60);
  return rm ? `${h} h ${rm} min` : `${h} h`;
}

export function dayKey(ts: number): string {
  const d = new Date(ts);
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
}

export function formatDay(ts: number, now = Date.now()): string {
  if (dayKey(ts) === dayKey(now)) return 'Today';
  if (dayKey(ts) === dayKey(now - 86400000)) return 'Yesterday';
  return new Date(ts).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
}

export function formatTime(ts: number): string {
  return new Date(ts).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
}
