/**
 * Low-intensity, synthesised ambience. A soft band of filtered noise (like
 * distant air or surf) opens on the inhale and closes on the exhale, over a
 * very quiet, slowly shifting drone. Created only after a user gesture.
 */

type Ctor = typeof AudioContext;

export function audioSupported(): boolean {
  return typeof window !== 'undefined' && !!(window.AudioContext || (window as unknown as { webkitAudioContext?: Ctor }).webkitAudioContext);
}

export class Ambience {
  private ctx: AudioContext;
  private master: GainNode;
  private air: GainNode;
  private filter: BiquadFilterNode;
  private droneGain: GainNode;
  private oscs: OscillatorNode[] = [];
  private noise: AudioBufferSourceNode;
  private lastUpdate = 0;
  private on = false;

  static create(): Ambience | null {
    if (!audioSupported()) return null;
    try {
      return new Ambience();
    } catch {
      return null;
    }
  }

  private constructor() {
    const C: Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: Ctor }).webkitAudioContext;
    const ctx = (this.ctx = new C());
    this.master = ctx.createGain();
    this.master.gain.value = 0;
    this.master.connect(ctx.destination);

    // Pink-ish noise loop.
    const len = ctx.sampleRate * 4;
    const buf = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = buf.getChannelData(ch);
      let b0 = 0, b1 = 0, b2 = 0;
      for (let i = 0; i < len; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99765 * b0 + white * 0.099046;
        b1 = 0.963 * b1 + white * 0.2965164;
        b2 = 0.57 * b2 + white * 1.0526913;
        d[i] = (b0 + b1 + b2 + white * 0.1848) * 0.12;
      }
      // Cross-fade the loop point.
      const fade = 2048;
      for (let i = 0; i < fade; i++) {
        const t = i / fade;
        d[i] = d[i] * t + d[len - fade + i] * (1 - t);
      }
    }
    this.noise = ctx.createBufferSource();
    this.noise.buffer = buf;
    this.noise.loop = true;
    this.filter = ctx.createBiquadFilter();
    this.filter.type = 'lowpass';
    this.filter.frequency.value = 380;
    this.filter.Q.value = 0.4;
    this.air = ctx.createGain();
    this.air.gain.value = 0.25;
    this.noise.connect(this.filter).connect(this.air).connect(this.master);
    this.noise.start();

    this.droneGain = ctx.createGain();
    this.droneGain.gain.value = 0.05;
    this.droneGain.connect(this.master);
    [98, 146.83, 196.5].forEach((freq, i) => {
      const o = ctx.createOscillator();
      o.type = 'sine';
      o.frequency.value = freq;
      const g = ctx.createGain();
      g.gain.value = [0.5, 0.28, 0.12][i];
      // Very slow tremolo so it breathes rather than buzzes.
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.05 + i * 0.023;
      const lg = ctx.createGain();
      lg.gain.value = g.gain.value * 0.4;
      lfo.connect(lg).connect(g.gain);
      o.connect(g).connect(this.droneGain);
      o.start();
      lfo.start();
      this.oscs.push(o, lfo);
    });
  }

  async setEnabled(on: boolean) {
    this.on = on;
    const now = this.ctx.currentTime;
    if (on && this.ctx.state === 'suspended') {
      try { await this.ctx.resume(); } catch { /* ignore */ }
    }
    this.master.gain.cancelScheduledValues(now);
    this.master.gain.setTargetAtTime(on ? 0.55 : 0, now, on ? 1.2 : 0.35);
  }

  /** Called every frame; throttled internally. */
  setBreath(fullness: number) {
    if (!this.on) return;
    const now = this.ctx.currentTime;
    if (now - this.lastUpdate < 0.08) return;
    this.lastUpdate = now;
    this.filter.frequency.setTargetAtTime(260 + fullness * 900, now, 0.25);
    this.air.gain.setTargetAtTime(0.16 + fullness * 0.22, now, 0.3);
  }

  /** A soft, low bell. Used sparingly: start of a breath in quiet mode, and the end of a session. */
  chime(level = 1) {
    if (!this.on) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;
    [392, 588.6, 784.4].forEach((freq, i) => {
      const o = ctx.createOscillator();
      o.type = 'sine';
      o.frequency.value = freq;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, now);
      g.gain.linearRampToValueAtTime(0.05 * level * [1, 0.4, 0.18][i], now + 0.04);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 3.5 - i * 0.6);
      o.connect(g).connect(this.master);
      o.start(now);
      o.stop(now + 3.6);
    });
  }

  dispose() {
    try {
      this.noise.stop();
      this.oscs.forEach((o) => o.stop());
      void this.ctx.close();
    } catch { /* ignore */ }
  }
}
