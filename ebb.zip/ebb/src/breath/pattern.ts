/**
 * Breathing patterns and the pure function that turns elapsed time into a
 * breath sample. Everything visual and audible is derived from this, so the
 * experience stays in sync no matter how often (or rarely) frames are drawn.
 */

export type Phase = 'inhale' | 'hold' | 'exhale' | 'rest';

export interface BreathPattern {
  /** Seconds. */
  inhale: number;
  /** Hold after inhaling. 0 disables it. */
  hold: number;
  exhale: number;
  /** Pause after exhaling. 0 disables it. */
  rest: number;
}

export interface BreathSample {
  phase: Phase;
  /** 0..1 progress through the current phase. */
  phaseProgress: number;
  /** Seconds remaining in the current phase. */
  phaseRemaining: number;
  /** 0 = fully exhaled, 1 = fully inhaled. Eased, continuous. */
  fullness: number;
  /** Index of the current breath cycle, starting at 0. */
  cycle: number;
  /** Seconds into the current cycle. */
  cycleTime: number;
}

export interface PatternPreset {
  id: string;
  name: string;
  note: string;
  pattern: BreathPattern;
}

export const PRESETS: PatternPreset[] = [
  { id: 'gentle', name: 'Gentle', note: 'In 4 · hold 2 · out 6', pattern: { inhale: 4, hold: 2, exhale: 6, rest: 0 } },
  { id: 'soft', name: 'Soft', note: 'In 4 · out 6, no holds', pattern: { inhale: 4, hold: 0, exhale: 6, rest: 0 } },
  { id: 'even', name: 'Even', note: 'In 5 · out 5', pattern: { inhale: 5, hold: 0, exhale: 5, rest: 0 } },
  { id: 'square', name: 'Square', note: 'In 4 · hold 4 · out 4 · rest 4', pattern: { inhale: 4, hold: 4, exhale: 4, rest: 4 } },
];

export const LIMITS = {
  inhale: { min: 2, max: 10 },
  hold: { min: 0, max: 8 },
  exhale: { min: 2, max: 12 },
  rest: { min: 0, max: 8 },
} as const;

export function clampPattern(p: BreathPattern): BreathPattern {
  const c = (v: number, k: keyof typeof LIMITS) =>
    Math.min(LIMITS[k].max, Math.max(LIMITS[k].min, Number.isFinite(v) ? Math.round(v * 2) / 2 : LIMITS[k].min));
  return { inhale: c(p.inhale, 'inhale'), hold: c(p.hold, 'hold'), exhale: c(p.exhale, 'exhale'), rest: c(p.rest, 'rest') };
}

export function cycleLength(p: BreathPattern): number {
  return p.inhale + p.hold + p.exhale + p.rest;
}

export function presetFor(p: BreathPattern): PatternPreset | undefined {
  return PRESETS.find(
    (x) => x.pattern.inhale === p.inhale && x.pattern.hold === p.hold && x.pattern.exhale === p.exhale && x.pattern.rest === p.rest,
  );
}

/** Sine ease: slow at both ends, like a natural breath. */
export const easeBreath = (t: number) => 0.5 - 0.5 * Math.cos(Math.PI * Math.min(1, Math.max(0, t)));

export function sampleBreath(p: BreathPattern, elapsedSeconds: number): BreathSample {
  const len = cycleLength(p);
  const t = Math.max(0, elapsedSeconds);
  const cycle = Math.floor(t / len);
  const ct = t - cycle * len;

  let phase: Phase;
  let start: number;
  let dur: number;
  if (ct < p.inhale) {
    phase = 'inhale'; start = 0; dur = p.inhale;
  } else if (ct < p.inhale + p.hold) {
    phase = 'hold'; start = p.inhale; dur = p.hold;
  } else if (ct < p.inhale + p.hold + p.exhale) {
    phase = 'exhale'; start = p.inhale + p.hold; dur = p.exhale;
  } else {
    phase = 'rest'; start = p.inhale + p.hold + p.exhale; dur = p.rest;
  }
  const progress = dur > 0 ? (ct - start) / dur : 1;

  let fullness: number;
  switch (phase) {
    case 'inhale': fullness = easeBreath(progress); break;
    case 'hold': fullness = 1; break;
    case 'exhale': fullness = 1 - easeBreath(progress); break;
    default: fullness = 0;
  }

  return { phase, phaseProgress: progress, phaseRemaining: dur - (ct - start), fullness, cycle, cycleTime: ct };
}

/** Seconds from `elapsed` until the end of the current cycle's exhale (or rest). */
export function secondsToCycleEnd(p: BreathPattern, elapsedSeconds: number): number {
  const len = cycleLength(p);
  const ct = elapsedSeconds % len;
  return len - ct;
}

export const PHASE_WORD: Record<Phase, string> = {
  inhale: 'Breathe in',
  hold: 'Hold gently',
  exhale: 'Let it go',
  rest: 'Rest',
};
