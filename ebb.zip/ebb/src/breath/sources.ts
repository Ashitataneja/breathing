/**
 * A BreathSource is anything that can tell the environment how "full" the
 * breath is at a given moment. Today there are two honest sources:
 *
 *  - GuidedSource: follows a chosen pattern. The visuals lead; you follow.
 *  - OpenSource:   no pacing at all. The environment drifts very slowly and
 *                  you breathe at your own rhythm.
 *
 * Neither detects the user's breath. A future SensorSource (microphone,
 * camera, chest-strap, etc.) would implement the same interface, add an
 * explicit `start()` permission step, and report `kind: 'sensor'`. The
 * renderer, audio and session engine would not need to change.
 */

import { BreathPattern, Phase, sampleBreath } from './pattern';

export interface BreathSignal {
  /** 0 = empty, 1 = full. */
  fullness: number;
  /** null when the source has no notion of phases (open mode). */
  phase: Phase | null;
  phaseProgress: number;
  cycle: number;
}

export interface BreathSource {
  readonly kind: 'guided' | 'open' | 'sensor';
  sample(elapsedSeconds: number): BreathSignal;
}

export class GuidedSource implements BreathSource {
  readonly kind = 'guided' as const;
  constructor(public pattern: BreathPattern) {}
  sample(t: number): BreathSignal {
    const s = sampleBreath(this.pattern, t);
    return { fullness: s.fullness, phase: s.phase, phaseProgress: s.phaseProgress, cycle: s.cycle };
  }
}

export class OpenSource implements BreathSource {
  readonly kind = 'open' as const;
  sample(t: number): BreathSignal {
    // Deliberately slower and less regular than any breath, so it never
    // reads as an instruction — just a living, resting presence.
    const f = 0.42 + 0.1 * Math.sin(t * 0.21) + 0.05 * Math.sin(t * 0.077 + 1.3);
    return { fullness: f, phase: null, phaseProgress: 0, cycle: 0 };
  }
}
